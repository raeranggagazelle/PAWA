CREATE DATABASE IF NOT EXISTS kost_mvc;
USE kost_mvc;

DROP TABLE IF EXISTS rentals;
DROP TABLE IF EXISTS rooms;

CREATE TABLE rooms (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    harga INT NOT NULL,
    deskripsi TEXT
);

INSERT INTO rooms (nama, harga, deskripsi) VALUES
('Kamar Standard', 800000, 'Kipas angin, kamar mandi luar, wifi.'),
('Kamar AC', 1200000, 'AC, kamar mandi dalam, wifi.'),
('Kamar Premium', 1800000, 'AC, kamar mandi dalam, air panas, meja kerja.');

CREATE TABLE rentals (
    id INT AUTO_INCREMENT PRIMARY KEY,
    room_id INT NOT NULL,
    penyewa VARCHAR(100) NOT NULL,
    durasi_bulan INT NOT NULL DEFAULT 1,
    total_bayar INT NOT NULL DEFAULT 0,
    status ENUM('dipesan', 'dibayar', 'keluar') NOT NULL DEFAULT 'dipesan',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_room FOREIGN KEY (room_id) REFERENCES rooms (id) ON DELETE CASCADE
);

