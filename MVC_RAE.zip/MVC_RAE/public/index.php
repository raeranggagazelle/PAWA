<?php
session_start();

require_once __DIR__ . '/../app/core/Database.php';
require_once __DIR__ . '/../app/models/Room.php';
require_once __DIR__ . '/../app/models/Rental.php';
require_once __DIR__ . '/../app/controllers/HomeController.php';
require_once __DIR__ . '/../app/controllers/RentalController.php';

$homeController = new HomeController();
$rentalController = new RentalController();

$action = $_GET['action'] ?? 'home';

switch ($action) {
    case 'rent':
        $rentalController->rent($_POST);
        header('Location: /MVC_RAE/public/index.php');
        exit;
    case 'pay':
        $rentalController->pay($_POST);
        header('Location: /MVC_RAE/public/index.php');
        exit;
    case 'checkout':
        $rentalController->checkout($_POST);
        header('Location: /MVC_RAE/public/index.php');
        exit;
    default:
        $homeController->index();
}

