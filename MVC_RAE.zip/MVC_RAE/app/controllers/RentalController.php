<?php

class RentalController
{
    public function rent(array $data): void
    {
        $roomId = (int) ($data['room_id'] ?? 0);
        $penyewa = trim($data['penyewa'] ?? '');
        $durasi = (int) ($data['durasi'] ?? 1);

        if ($roomId <= 0 || $penyewa === '') {
            return;
        }

        $room = Room::find($roomId);
        if (!$room) {
            return;
        }

        Rental::rent($roomId, $penyewa, max(1, $durasi));
    }

    public function pay(array $data): void
    {
        $rentalId = (int) ($data['rental_id'] ?? 0);
        $jumlah = (int) ($data['jumlah'] ?? 0);

        if ($rentalId > 0 && $jumlah > 0) {
            Rental::pay($rentalId, $jumlah);
        }
    }

    public function checkout(array $data): void
    {
        $rentalId = (int) ($data['rental_id'] ?? 0);

        if ($rentalId > 0) {
            Rental::checkout($rentalId);
        }
    }
}

