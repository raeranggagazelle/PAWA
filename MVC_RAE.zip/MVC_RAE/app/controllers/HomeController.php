<?php

class HomeController
{
    public function index(): void
    {
        $rooms = Room::all();
        $rentals = Rental::all();

        require __DIR__ . '/../views/layout/header.php';
        require __DIR__ . '/../views/home.php';
        require __DIR__ . '/../views/layout/footer.php';
    }
}

