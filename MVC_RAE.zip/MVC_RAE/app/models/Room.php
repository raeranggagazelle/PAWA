<?php

class Room
{
    public static function all(): array
    {
        $stmt = Database::connection()->query('SELECT id, nama, harga, deskripsi FROM rooms ORDER BY id');
        return $stmt->fetchAll();
    }

    public static function find(int $id): ?array
    {
        $stmt = Database::connection()->prepare('SELECT id, nama, harga, deskripsi FROM rooms WHERE id = :id');
        $stmt->execute(['id' => $id]);
        $room = $stmt->fetch();

        return $room ?: null;
    }
}

