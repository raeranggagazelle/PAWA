<?php

class Rental
{
    public static function all(): array
    {
        $sql = 'SELECT r.*, rm.nama AS room_nama, rm.harga AS room_harga
                FROM rentals r
                JOIN rooms rm ON rm.id = r.room_id
                ORDER BY r.id DESC';

        $stmt = Database::connection()->query($sql);
        return $stmt->fetchAll();
    }

    public static function find(int $id): ?array
    {
        $sql = 'SELECT r.*, rm.nama AS room_nama, rm.harga AS room_harga
                FROM rentals r
                JOIN rooms rm ON rm.id = r.room_id
                WHERE r.id = :id';

        $stmt = Database::connection()->prepare($sql);
        $stmt->execute(['id' => $id]);
        $rental = $stmt->fetch();

        return $rental ?: null;
    }

    public static function rent(int $roomId, string $penyewa, int $durasiBulan): void
    {
        $sql = 'INSERT INTO rentals (room_id, penyewa, durasi_bulan, total_bayar, status)
                VALUES (:room_id, :penyewa, :durasi_bulan, 0, "dipesan")';

        $stmt = Database::connection()->prepare($sql);
        $stmt->execute([
            'room_id' => $roomId,
            'penyewa' => $penyewa,
            'durasi_bulan' => $durasiBulan,
        ]);
    }

    public static function pay(int $rentalId, int $jumlah): void
    {
        $sql = 'UPDATE rentals
                SET total_bayar = total_bayar + :jumlah, status = "dibayar"
                WHERE id = :id AND status <> "keluar"';

        $stmt = Database::connection()->prepare($sql);
        $stmt->execute([
            'jumlah' => $jumlah,
            'id' => $rentalId,
        ]);
    }

    public static function checkout(int $rentalId): void
    {
        $stmt = Database::connection()->prepare('UPDATE rentals SET status = "keluar" WHERE id = :id AND status <> "keluar"');
        $stmt->execute(['id' => $rentalId]);
    }
}

