<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aplikasi Kost</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; background: #f4f4f4; color: #222; }
        header { background: #2c3e50; color: #fff; padding: 16px 24px; }
        main { padding: 20px; max-width: 960px; margin: 0 auto; }
        .card { background: #fff; padding: 16px; margin-bottom: 16px; border-radius: 6px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
        .rooms { display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: 12px; }
        h1, h2, h3 { margin: 0 0 12px; }
        form { display: flex; flex-direction: column; gap: 8px; }
        label { font-weight: bold; }
        input, select, button { padding: 8px; border: 1px solid #ccc; border-radius: 4px; }
        button { background: #2c3e50; color: #fff; cursor: pointer; }
        button.secondary { background: #7f8c8d; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 10px; border: 1px solid #ddd; text-align: left; }
        .status { padding: 4px 8px; border-radius: 4px; display: inline-block; }
        .dipesan { background: #f1c40f; color: #222; }
        .dibayar { background: #2ecc71; color: #fff; }
        .keluar { background: #e74c3c; color: #fff; }
    </style>
</head>
<body>
<header>
    <h1>Kost telang </h1>
    <p>Fitur: penawaran kamar, sewa, pembayaran, keluar kost.</p>
</header>
<main>

