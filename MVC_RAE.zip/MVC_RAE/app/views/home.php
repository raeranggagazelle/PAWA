<section class="card">
    <h2>Penawaran Kamar Kost</h2>
    <div class="rooms">
        <?php foreach ($rooms as $room): ?>
            <div class="card" style="margin:0;">
                <h3><?= htmlspecialchars($room['nama']) ?></h3>
                <p><?= htmlspecialchars($room['deskripsi']) ?></p>
                <p><strong>Harga:</strong> Rp <?= number_format($room['harga'], 0, ',', '.') ?> / bulan</p>
                <form method="post" action="?action=rent">
                    <input type="hidden" name="room_id" value="<?= $room['id'] ?>">
                    <label>Nama Penyewa</label>
                    <input type="text" name="penyewa" required>
                    <label>Durasi (bulan)</label>
                    <input type="number" name="durasi" min="1" value="1" required>
                    <button type="submit">Sewa Sekarang</button>
                </form>
            </div>
        <?php endforeach; ?>
    </div>
</section>

<section class="card">
    <h2>Sewa Berjalan</h2>
    <?php if (empty($rentals)): ?>
        <p>Belum ada penyewaan.</p>
    <?php else: ?>
        <table>
            <thead>
                <tr>
                    <th>Kamar</th>
                    <th>Penyewa</th>
                    <th>Durasi</th>
                    <th>Total Bayar</th>
                    <th>Status</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($rentals as $rental): ?>
                    <tr>
                        <td><?= htmlspecialchars($rental['room_nama'] ?? 'Tidak diketahui') ?></td>
                        <td><?= htmlspecialchars($rental['penyewa']) ?></td>
                        <td><?= (int) $rental['durasi_bulan'] ?> bulan</td>
                        <td>Rp <?= number_format((int) $rental['total_bayar'], 0, ',', '.') ?></td>
                        <td><span class="status <?= $rental['status'] ?>"><?= $rental['status'] ?></span></td>
                        <td style="display:flex; gap:6px; flex-wrap:wrap;">
                            <?php if ($rental['status'] === 'dipesan'): ?>
                                <form method="post" action="?action=pay">
                                    <input type="hidden" name="rental_id" value="<?= $rental['id'] ?>">
                                    <input type="number" name="jumlah" min="50000" step="50000" placeholder="Jumlah bayar" required>
                                    <button type="submit">Bayar</button>
                                </form>
                            <?php endif; ?>

                            <?php if ($rental['status'] === 'dibayar'): ?>
                                <form method="post" action="?action=checkout">
                                    <input type="hidden" name="rental_id" value="<?= $rental['id'] ?>">
                                    <button type="submit" class="secondary">Keluar</button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</section>

